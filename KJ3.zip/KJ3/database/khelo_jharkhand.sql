-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2022 at 03:04 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `khelo_jharkhand`
--

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `game_id` int(100) NOT NULL,
  `organizer_email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `location` varchar(100) NOT NULL,
  `charge` int(100) NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`game_id`, `organizer_email`, `name`, `type`, `date`, `location`, `charge`, `photo`) VALUES
(113, 'rajg1@gmail.com', 'Hockey Jharkhand Cup 2022', 'Hockey', '2022-08-10', 'Helal,Pahar toli', 3000, 'Hockey Jharkhand Cup 2022.jfif'),
(115, 'champgears@gmail.com', 'Jharkhand Open', 'Football', '2022-08-18', 'Mega Sports Complex', 2000, 'Jharkhand Open.jfif'),
(116, 'champgears@gmail.com', 'Jharkhand Ashes Series', 'Cricket', '2022-08-20', 'Mega Sports Complex', 2000, 'Jharkhand Ashes Series.jfif'),
(117, 'jssps@gmail.com', 'Jharkhand Ranking tournament', 'Badminton', '2022-07-15', 'Ranchi Club Badminton Court', 1500, 'Jharkhand Ranking tournament.jfif'),
(118, 'jssps@gmail.com', 'Khassi tournament', 'Football', '2022-08-17', 'Birsa Munda Football Stadium', 3000, 'Khassi tournament.jpg'),
(119, 'saj@gmail.com', 'T20 Jharkhand League', 'Cricket', '2022-08-30', 'M.S. Dhoni Pavilion', 2200, 'T20 Jharkhand League.jfif'),
(120, 'saj@gmail.com', 'JCC', 'Cricket', '2022-07-01', 'Harivansh Tana Bhagat Indoor Stadium', 2000, 'JCC.jpg'),
(121, 'jcsa@gmail.com', 'JSCA tournament', 'Cricket', '2022-07-05', 'JSCA International Stadium Complex', 2800, 'JSCA tournament.jpg'),
(122, 'saj@gmail.com', 'Open kabaddi tournament', 'Kabbadi', '2022-08-16', 'Birsa Munda Athletics Stadium,Ranchi', 1500, 'Open kabaddi tournament.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `organizer`
--

CREATE TABLE `organizer` (
  `name` varchar(100) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `reg_id` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `organizer`
--

INSERT INTO `organizer` (`name`, `mobile`, `email`, `reg_id`, `address`, `password`, `photo`) VALUES
('Champ Gears', '2147483647', 'champgears@gmail.com', '512233445577', 'Tupudana,Ranchi', '9090', 'champ gears.png'),
('Jharkhand Company Sports Association', '2147483647', 'jcsa@gmail.com', '612233445577', 'Delatoli,Ranchi', '7777', 'jcsa.jfif'),
('Kabbadi Association of Jharkhand', '2147483647', 'jharkhandkabbadi@gmail.com', '312233445566', 'Bokaro', '8888', 'KAJ.jfif'),
('Jharkhand State Sports Promotion Society', '2147483647', 'jssps@gmail.com', '5122334455900', 'Khelgaon,Jharkhand', '9999', 'jssps.png'),
('Sports Authority of Jharkhand', '9876543210', 'saj@gmail.com', '112233344449', 'Kanke,Ranchi', '1234', 'SAJ.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE `player` (
  `player_id` int(100) NOT NULL,
  `team_email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `uid` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `player`
--

INSERT INTO `player` (`player_id`, `team_email`, `name`, `mobile`, `dob`, `uid`, `address`, `photo`) VALUES
(9, 'daggers@gmail.com', 'Saurabh Roy', '2147483647', '1995-11-25', '987654321001', 'Dharmshala Rd,Daltonganj', 'Saurabh Roy.jpg'),
(11, 'bkscblasters@gmail.com', 'Virat Singh', '2147483647', '1994-03-04', '456654322002', 'Sector-5(B),Qtr.no.321', 'Virat Singh.jpg'),
(12, 'daggers@gmail.com', 'Akash Raj', '9188776650', '1993-10-23', '456654321001', 'Old Bus Stand Rd,Daltonganj', 'Akash Raj.jfif'),
(13, 'daggers@gmail.com', 'Saloni Thakur', '7667778899', '1994-04-15', '556654322902', 'Shahpur Village,Palamu', 'Saloni Thakur.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `request_id` int(100) NOT NULL,
  `team_email` varchar(100) NOT NULL,
  `game_id` int(100) NOT NULL,
  `organizer_email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`request_id`, `team_email`, `game_id`, `organizer_email`) VALUES
(12, 'bkscblasters@gmail.com', 115, 'champgears@gmail.com'),
(13, 'daggers@gmail.com', 118, 'jssps@gmail.com'),
(14, 'daggers@gmail.com', 113, 'rajg1@gmail.com'),
(15, 'daggers@gmail.com', 117, 'jssps@gmail.com'),
(16, 'daggers@gmail.com', 118, 'jssps@gmail.com'),
(17, 'bkscblasters@gmail.com', 117, 'jssps@gmail.com'),
(18, 'daggers@gmail.com', 122, 'saj@gmail.com'),
(19, 'daggers@gmail.com', 117, 'jssps@gmail.com'),
(20, 'daggers@gmail.com', 119, 'saj@gmail.com'),
(21, 'bkscblasters@gmail.com', 120, 'saj@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `location` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`email`, `password`, `name`, `mobile`, `location`, `city`, `photo`) VALUES
('bkscblasters@gmail.com', '2222', 'Bokaro Blasters', '1234321001', 'Cooperative Colony', 'Bokaro Steel City', 'Bokaro Blasters.jfif'),
('daggers@gmail.com', '1010', 'Daltonganj Daggers', '2147483647', 'Sarvodaya Nagar', 'Daltonganj', 'Daltonganj Daggers.jfif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`game_id`);

--
-- Indexes for table `organizer`
--
ALTER TABLE `organizer`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `player`
--
ALTER TABLE `player`
  ADD PRIMARY KEY (`player_id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `game`
--
ALTER TABLE `game`
  MODIFY `game_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `player`
--
ALTER TABLE `player`
  MODIFY `player_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `request_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
